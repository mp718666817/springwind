package com.baomidou.springwind;

/**
 * 
 * spring-wind 春风，SSM架构核心库
 * 
 * Java 通用后台管理系统
 * 
 * @author hubin
 * 
 */
